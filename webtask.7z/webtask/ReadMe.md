# Knooing Task
This application is developed for Knooing task
	
## Assignment

* Complete html form by adding age input. Also implement restful web services to check age, persist data and list data

* Check Age[GET]

```   
/rest/rest/age/{age}
```

* Save user[POST]

```   
/rest/rest/users
```

* Get users[GET]

```   
/rest/rest/users
```

* Delete user[DELETE]

```   
/rest/rest/users/{id}
```





## Technologies

* Spring Boot - Framework
* H2 - Database
* Maven - Dependency Management
* AngularJS

## Install and Run

First run command below in terminal

```
mvn clean install
```

Then run jar file with command below in terminal

```
java -jar target/webtask.jar
```

## Test
Test can be run separately with commands below

```
mvn test
mvn verify
```

 