package com.knooing.webtask.controller;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.knooing.webtask.model.User;
import com.knooing.webtask.repository.UserRepository;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import java.util.Arrays;
import java.util.List;

import static org.hamcrest.Matchers.*;
import static org.mockito.ArgumentMatchers.any;

@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
public class UserControllerTest {

	@Autowired
	MockMvc mockMvc;

	@MockBean
	UserRepository repository;

	ObjectMapper mapper;
	
	@Before
	public void start()  {		
		mapper = new ObjectMapper();
	}
	
	@Test
	public void checkAgeTooYoung() throws Exception {
		mockMvc.perform(get("/rest/rest/age/17")
				.contentType(MediaType.APPLICATION_JSON_UTF8))
				.andExpect(jsonPath("$.ageMessage", is("too young")))
				;
	}
	
	@Test
	public void checkAgeTooOld() throws Exception {
		mockMvc.perform(get("/rest/rest/age/67")
				.contentType(MediaType.APPLICATION_JSON_UTF8))
				.andExpect(jsonPath("$.ageMessage", is("too old")))
				;
	}
	
	@Test
	public void checkAgeFunny() throws Exception {
		mockMvc.perform(get("/rest/rest/age/23")
				.contentType(MediaType.APPLICATION_JSON_UTF8))
				.andExpect(jsonPath("$.ageMessage", is("funny")))
				;
	}
	
	@Test
	public void checkAgeOK() throws Exception {
		mockMvc.perform(get("/rest/rest/age/42")
				.contentType(MediaType.APPLICATION_JSON_UTF8))
				.andExpect(jsonPath("$.ageMessage", is("OK")))
				;
	}
	
	
	@Test
	public void saveUserTest() throws JsonProcessingException, Exception {
		
		User user = new User("xxx", "abc", "def", 45);
		when(repository.save(any(User.class))).thenReturn(user);
		
		mockMvc.perform(post("/rest/rest/users/")
				.contentType(MediaType.APPLICATION_JSON_UTF8)
				.content(mapper.writeValueAsString(user)))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.id", is("xxx")))
				.andExpect(jsonPath("$.lastName", is("abc")))
				.andExpect(jsonPath("$.firstName", is("def")))
				.andExpect(jsonPath("$.age", is(45)))
				;
				
	}
	
	
	@Test
	public void getUsersTest() throws Exception {
		
		List<User> users = Arrays.asList(
				new User("1", "abc", "def", 41),
				new User("2", "sname", "fname", 42)
				);
		when(repository.findAll()).thenReturn(users);
		
		mockMvc.perform(get("/rest/rest/users/")
			.contentType(MediaType.APPLICATION_JSON_UTF8))
			.andExpect(jsonPath("$", hasSize(2)))
			.andExpect(jsonPath("$[0].id", is("1")))
			.andExpect(jsonPath("$[0].lastName", is("abc")))
			.andExpect(jsonPath("$[0].firstName", is("def")))
			.andExpect(jsonPath("$[0].age", is(41)))
			.andExpect(jsonPath("$[1].id", is("2")))
			.andExpect(jsonPath("$[1].lastName", is("sname")))
			.andExpect(jsonPath("$[1].firstName", is("fname")))
			.andExpect(jsonPath("$[1].age", is(42)))
			;
		
	}
	
	
} 
