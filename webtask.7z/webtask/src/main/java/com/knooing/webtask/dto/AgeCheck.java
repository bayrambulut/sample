package com.knooing.webtask.dto;

public class AgeCheck {

	private String ageMessage;

	public AgeCheck(String ageMessage) {
		this.ageMessage = ageMessage;
	}
	
	public String getAgeMessage() {
		return ageMessage;
	}

	public void setAgeMessage(String ageMessage) {
		this.ageMessage = ageMessage;
	}
}
