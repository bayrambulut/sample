package com.knooing.webtask.controller;

import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.knooing.webtask.dto.AgeCheck;
import com.knooing.webtask.model.User;
import com.knooing.webtask.repository.UserRepository;

@RestController
public class UserController {

	@Autowired
	UserRepository repository; 
	
	/**
	 * Saves user to database
	 * @param user
	 * @return
	 */
	
	@PostMapping("/rest/rest/users")
	public User saveUser(@RequestBody User user) {
		
		User u = user;
		u.setId(UUID.randomUUID().toString());		
		return repository.save(user);
	}
	
	/**
	 * Retrieves users from database  
	 * @return
	 */
	
	@GetMapping("/rest/rest/users")
	public List<User> getUsers() {
		return (List<User>) repository.findAll();
	}

	/**
	 * Removes user from database
	 * @param id
	 */
	@DeleteMapping("/rest/rest/users/{id}")
	public void deleteUser(@PathVariable("id") String id) {
		repository.deleteById(id);
	}
	
	/**
	 * Checks the age if is too old, too young, funny or OK
	 * @param age
	 * @return
	 */
	@GetMapping("/rest/rest/age/{age}")
	public AgeCheck checkAge(@PathVariable("age") int age) {
		
		if(age < 18)
			return new AgeCheck("too young");
		else if(age > 65)
			return new AgeCheck("too old");
		else if(checkPrime(age))
			return new AgeCheck("funny");
		else
			return new AgeCheck("OK");
		
				
	}
	
	/**
	 * Checks the given number if prime
	 * @param n
	 * @return
	 */
	
	public boolean checkPrime(int n) {
		
		for(int i=2;i<n;i++) {
	        if(n%i==0)
	            return false;
	    }
	    return true;
	}

	
}
