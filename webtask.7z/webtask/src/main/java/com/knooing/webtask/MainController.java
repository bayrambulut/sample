package com.knooing.webtask;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MainController {

	/**
	 * Start of application
	 * @return
	 */
    @GetMapping({"/"})
    public ModelAndView index() {
        ModelAndView mav = new ModelAndView("/index");
        mav.addObject("formName", "Anmeldeformular");
        return mav;
    }

    
}
