var myController = myApp.controller('myController', ['UserService', '$scope', function(UserService, $scope){
	
	var self=this;
	
	self.ageMessage = "";
	self.user = {lastName:'', firstName:'', age : null};
	
	self.objSearch = {name:'', surname:''};
	
	self.addUser = addUser;
	self.deleteUser = deleteUser;
	
	//self.search = search;
	self.users=[];
	
	getUsers();
	
	$scope.changeHandler = function() {
		if(self.user.age !=null) {
			UserService.checkAge(self.user.age)
				.then(function(successResponse){
					self.ageMessage = successResponse.ageMessage;
				},
				function(errResponse) {});
		}
	}
	
	function deleteUser(userId) {
		UserService.deleteUser(userId)
			.then(function(successResponse) {
				getUsers();
		}, function(errResponse) {});
	}
	
	function addUser() {		
		UserService.addUser(self.user)
			.then(function(successResponse) {
				getUsers();
				//reset
				self.user = {lastName:'', firstName:'', age : null};
				self.ageMessage = "";
			}, function(errResponse) {});		
	};
	
	
	
	function getUsers() {
		UserService.getUsers()
			.then(function(successResponse){self.users = successResponse},
					function(errResponse) {});
	}
	
	
	
}]);