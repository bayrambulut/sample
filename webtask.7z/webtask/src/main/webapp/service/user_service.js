var myApp = angular.module("myApp", []);

myApp.factory('UserService', ['$http', '$q', function($http, $q){
	
	var factory = {
		checkAge : checkAge,
		addUser : addUser,
		getUsers : getUsers,
		deleteUser : deleteUser
	}
	return factory;
	
	
	function checkAge(age) {
		var deferred = $q.defer();
		$http.get("http://localhost:8080/rest/rest/age/" + age).
			then(function(successResponse) {deferred.resolve(successResponse.data)},
					function(errResponse) {deferred.reject(errResponse)});
		return deferred.promise;
	};
	
	function addUser(user) {
		var deferred = $q.defer();
		$http.post("http://localhost:8080/rest/rest/users", user).
			then(function(successResponse) {deferred.resolve(successResponse.data)},
					function(errResponse) {deferred.reject(errResponse)});
		return deferred.promise;
	};
	
	
	function getUsers() {
		var deferred = $q.defer();
		$http.get("http://localhost:8080/rest/rest/users").
			then(function(successResponse) {deferred.resolve(successResponse.data)},
					function(errResponse) {deferred.reject(errResponse)});
		return deferred.promise;
	};
	
	function deleteUser(userId) {
		var deferred = $q.defer();
		$http.delete("http://localhost:8080/rest/rest/users/" + userId).
			then(function(successResponse) {deferred.resolve(successResponse.data)},
					function(errResponse) {deferred.reject(errResponse)});
		return deferred.promise;
	};
	
	/*
	var url = "http://localhost:7777/addUser"
	
	var factory = {
		add_object : add_object,
		listUsers : listUsers,
		searchUsers : searchUsers
	};
	return factory;
	
	function add_object(obj) {
		var deferred = $q.defer();
		$http.post(url, obj).
			then(function(successResponse) {deferred.resolve(successResponse.data)},
					function(errResponse) {deferred.reject(errResponse)});
		return deferred.promise;
	};
	

	
	function searchUsers(obj) {
		var deferred = $q.defer();
		$http.post("http://localhost:7777/users", obj).
			then(function(successResponse) {deferred.resolve(successResponse.data)},
					function(errResponse) {deferred.reject(errResponse)});
		return deferred.promise;
	};
	*/
	
}])
